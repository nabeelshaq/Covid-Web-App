using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;
  
namespace program.Pages  
{  
    public class CompareStatesInfo : PageModel  
    {  
        public List<string> dates { get; set; }
        public List<int> positiveIncrease { get; set; }
        public List<int> positiveIncrease1 { get; set; }
        public List<int> positiveIncrease2 { get; set; }
        public List<int> negativeIncrease { get; set; }
        public List<int> negativeIncrease1 { get; set; }
        public List<int> negativeIncrease2 { get; set; }
        public string Input { get; set; }
        public string Input1 { get; set; }
        public string Input2 { get; set; }
        public Exception EX { get; set; }
  
        public void OnGet(string input, string input1, string input2)  
        {
          dates = new List<string>();
          positiveIncrease = new List<int>();
          positiveIncrease1 = new List<int>();
          positiveIncrease2 = new List<int>();
          negativeIncrease = new List<int>();
          negativeIncrease1 = new List<int>();
          negativeIncrease2 = new List<int>();
          Input = input;
          Input1 = input1;
          Input2 = input2;
          EX = null;
          
          try
          {
          if (input == null || input1 == null || input2 == null){}
          else{
            input = input.Replace("'", "''");
            input1 = input1.Replace("'", "''");
            input2 = input2.Replace("'", "''");
            string sql = string.Format(@"
SELECT date, state, positiveIncrease, negativeIncrease
FROM us_states_covid19_daily
WHERE state like '{0}' OR state like '{1}' OR state like '{2}'
ORDER BY date;
",input, input1, input2);
          
            DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);

            foreach (DataRow row in ds.Tables[0].Rows)
            {
              string date = Convert.ToString(row["date"]);
              dates.Add(date);
              string state = Convert.ToString(row["state"]);
              
              if (state == input){
                int posIncrease = Convert.ToInt32(row["positiveIncrease"]);
                positiveIncrease.Add(posIncrease);
                int negIncrease = Convert.ToInt32(row["negativeIncrease"]);
                negativeIncrease.Add(negIncrease);
                
              }
              if (state == input1){
                int posIncrease1 = Convert.ToInt32(row["positiveIncrease"]);
                positiveIncrease1.Add(posIncrease1);
                int negIncrease1 = Convert.ToInt32(row["negativeIncrease"]);
                negativeIncrease1.Add(negIncrease1);
              }
              if (state == input2){
                int posIncrease2 = Convert.ToInt32(row["positiveIncrease"]);
                positiveIncrease2.Add(posIncrease2);
                int negIncrease2 = Convert.ToInt32(row["negativeIncrease"]);
                negativeIncrease2.Add(negIncrease2);
              }
              dates=dates.Distinct().ToList();
              while(positiveIncrease.Count < dates.Count){
                  positiveIncrease.Insert(0,0);
              }
              while(negativeIncrease.Count < dates.Count){
                  negativeIncrease.Insert(0,0);
              }
              while(positiveIncrease1.Count < dates.Count){
                  positiveIncrease1.Insert(0,0);
              }
              while(negativeIncrease1.Count < dates.Count){
                  negativeIncrease1.Insert(0,0);
              }
              while(positiveIncrease2.Count < dates.Count){
                  positiveIncrease2.Insert(0,0);
              }
              while(negativeIncrease2.Count < dates.Count){
                  negativeIncrease2.Insert(0,0);
              }
              
              
            }
            
            }
		      }
		      catch(Exception ex)
		      {
            EX = ex;
		      }
		      finally
		      { 
            // nothing at the moment
          } 
        }
        
        
        
        
    }//class
}//namespace